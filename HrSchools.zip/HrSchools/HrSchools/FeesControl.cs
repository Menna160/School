﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HrSchools
{
    public partial class FeesControl : Form
    {
        public FeesControl()
        {
            InitializeComponent();
        }

        

        private void FeesControl_Load(object sender, EventArgs e)
        {
            

        }

        private void button2_Click(object sender, EventArgs e)
        {
            FeesOpreation f = new FeesOpreation();
            f.Show();
            f.Discount.Enabled = false;
            f.DateofPaid.Enabled = false;
            f.Costprice.Enabled = false;
            f.Cost.Enabled = false;
            f.Paid.Enabled = false;
            f.PaidType.Enabled = false;
            f.StudentName.Enabled = false;
            f.Updateme.Enabled = false;
            f.Remain.Enabled = false;
            this.Hide();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            FeesOpreation f = new FeesOpreation();
            f.Show();
            f.deletemy.Enabled = false;
            f.Discount.Enabled = false;
            f.DateofPaid.Text = DateTime.Now.ToString();
            f.DateofPaid.Enabled = false;
            f.Costprice.Enabled = false;
            f.Cost.Enabled = false;
            f.Remain.Enabled = false;

            f.PaidType.Enabled = false;
            f.StudentName.Enabled = false;
            this.Hide();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Searchfees s = new Searchfees();
            s.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {

            usercontrol u = new usercontrol();
            u.Show();
            this.Hide();

           
            
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            insertfees f = new insertfees();
            f.Show();
            this.Hide();
        }
    }
}
