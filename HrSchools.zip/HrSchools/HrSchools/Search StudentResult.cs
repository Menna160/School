﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HrSchools
{
    public partial class Search_StudentResult : Form
    {
        public Search_StudentResult()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            int a = Convert.ToInt32(textBox1.Text);
            ConnectionClass c = new ConnectionClass();
            c.PoolConnection();
            c.CMD.CommandText = "Select Studentname from Result where Fkstdid=" + a + "";
            c.DR = c.CMD.ExecuteReader();
            if (c.DR.Read())
            {

                txtno.Text = c.DR[0].ToString();

            }
        }

       

      
        private void Search_StudentResult_Load(object sender, EventArgs e)
        {
           // label21.Visible = false;
        }

        private void arbic_TextChanged(object sender, EventArgs e)
        {

        }

        private void Save_Click(object sender, EventArgs e)
        {
            SearchResult s = new SearchResult();
            s.Show();
            this.Hide();
        }

        private void arbic_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar) || e.KeyChar == '\b')
            {
                // Allow Digits and BackSpace char
            }
            else if (e.KeyChar == '.' )
            {
                //Allows only one Dot Char
                e.Handled = true;
            }
            
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            ResultControl r = new ResultControl();
            r.Show();
            this.Hide();
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            txtfre.Text = "";
            txtno.Text = "";
            act.Text = "";
            arbic.Text = "";
            math.Text = "";
            rel.Text = "";
            geo.Text = "";
            his.Text = "";
            rel.BackColor = Color.White;
            arbic.BackColor = Color.White;
            Eng.BackColor = Color.White;
            FRe.BackColor = Color.White;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                ConnectionClass c = new ConnectionClass();
                c.PoolConnection();
                c.CMD.CommandText = "select Arabic,English,French,Science,math,historic,geo,religon,otherActive,Totel from Result where studentname='" + txtno.Text + "'";
                c.DR = c.CMD.ExecuteReader();
                if (c.DR.Read())
                {
                    arbic.Text = c.DR[0].ToString();
                    Eng.Text = c.DR[1].ToString();
                    FRe.Text = c.DR[2].ToString();
                    txtfre.Text = c.DR[0].ToString();
                    math.Text = c.DR[4].ToString();
                    his.Text = c.DR[5].ToString();
                    geo.Text = c.DR[6].ToString();
                    rel.Text = c.DR[7].ToString();
                    act.Text = c.DR[8].ToString();
                    textBox4.Text = c.DR[9].ToString();

                    int a = int.Parse(arbic.Text);
                    if (a < 50) { arbic.BackColor = Color.Yellow; }
                    else { arbic.BackColor = Color.White; }

                    int b = int.Parse(Eng.Text);
                    if (b < 25) { Eng.BackColor = Color.Yellow; }
                    else { Eng.BackColor = Color.White; }
                    int c1 = int.Parse(FRe.Text);
                    if (c1 < 25) { FRe.BackColor = Color.Yellow; }
                    else { FRe.BackColor = Color.White; }
                    int d = int.Parse(txtfre.Text);
                    if (d < 25) { txtfre.BackColor = Color.Yellow; }
                    else { txtfre.BackColor = Color.White; }
                    int f = int.Parse(math.Text);
                    if (f < 50) { math.BackColor = Color.Yellow; }
                    else { math.BackColor = Color.White; }
                    int g = int.Parse(his.Text);
                    if (g < 12) { his.BackColor = Color.Yellow; }
                    else { his.BackColor = Color.White; }
                    int k = int.Parse(geo.Text);
                    if (k < 12)
                    {
                        geo.BackColor = Color.Yellow;
                        
                    }
                    else { geo.BackColor = Color.White; }
                    int h = int.Parse(rel.Text);
                    if (h < 12) { rel.BackColor = Color.Yellow; }
                    else { rel.BackColor = Color.White; }
                    int y = int.Parse(act.Text);
                    if (y < 10) { act.BackColor = Color.Yellow; }
                    else { act.BackColor = Color.White; }

                }
                else { MessageBox.Show("not "); }
            }
            catch { }

        }

        private void txtno_TextChanged(object sender, EventArgs e)
        {
            AutoCompleteStringCollection ayman = new AutoCompleteStringCollection();

            // listBox1.Show();
            ConnectionClass con = new ConnectionClass();
            con.PoolConnection();
            con.CMD.CommandText = "select Studentname from Result where Studentname  like +@name+'%'";
            con.CMD.Parameters.Add("@name", SqlDbType.NVarChar, 50).Value = txtno.Text;
            con.DR = con.CMD.ExecuteReader();
            while (con.DR.Read())
            {
                // listBox1.Items.Add(con.DR[0].ToString());
                ayman.Add(con.DR[0].ToString());

            }
            txtno.AutoCompleteMode = AutoCompleteMode.Suggest;
            txtno.AutoCompleteSource = AutoCompleteSource.CustomSource;
            txtno.AutoCompleteCustomSource = ayman;
            //searche for  Student id
            try
            {
                // int a = Convert.ToInt32(textBox1.Text);
                ConnectionClass c = new ConnectionClass();
                c.PoolConnection();
                c.CMD.CommandText = "Select fkStdid,Stage,Classid from Result where StudentName='" + txtno.Text + "'";
                c.DR = c.CMD.ExecuteReader();
                if (c.DR.Read())
                {
                    textBox1.Text = c.DR[0].ToString();
                    textBox2.Text = c.DR[1].ToString();
                    textBox3.Text = c.DR[2].ToString();

                }
                else { textBox1.Text = ""; textBox2.Text = ""; textBox3.Text = ""; }
            }
            catch { }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void BTNclose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtno_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && e.KeyChar != ' ')
            {
                e.Handled = true;
            }


            if (e.KeyChar == ' '
                && (sender as TextBox).Text.IndexOf(' ') > -1)
            {
                e.Handled = true;
            }
            
            
        }
    }
}
