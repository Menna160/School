﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HrSchools
{
    public partial class otherOperation : Form
    {
        public otherOperation()
        {
            InitializeComponent();
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            TXTnamesDelete.Text = "";
           
            arabic.Text = "";
            arabic.BackColor = Color.White;
            English.Text = "";
            English.BackColor = Color.White;
            French.Text = "";
            French.BackColor = Color.White;
            Science.Text = "";
            Science.BackColor = Color.White;
            Math.Text = "";
            Math.BackColor = Color.White;
            Hist.Text = "";
            Hist.BackColor = Color.White;
            Geo.Text = "";
            Geo.BackColor = Color.White;
            Religon.Text = "";
            Religon.BackColor = Color.White;
            active.Text = "";
            active.BackColor = Color.White; 
        }

        private void BTNclose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            ResultControl r = new ResultControl();
            r.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show("Would You like Delete this data","Warring Message",MessageBoxButtons.OKCancel,MessageBoxIcon.Warning);
            if (r == DialogResult.OK)
            {
                ConnectionClass c = new ConnectionClass();
                c.PoolConnection();
                c.CMD.CommandText = "delete Result Where StudentName ='"+TXTnamesDelete.Text+"'";
                c.CMD.ExecuteNonQuery();
                DialogResult r1=MessageBox.Show("Deleted Student Result","Message",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                if (r1 == DialogResult.OK)
                {
                    TXTnamesDelete.Text = "";
                    arabic.Text = "";
                    arabic.BackColor = Color.White;
                    English.Text = "";
                    English.BackColor = Color.White;
                    French.Text = "";
                    French.BackColor = Color.White;
                    Science.Text = "";
                    Science.BackColor = Color.White;
                    Math.Text = "";
                    Math.BackColor = Color.White;
                    Hist.Text = "";
                    Hist.BackColor = Color.White;
                    Geo.Text = "";
                    Geo.BackColor = Color.White;
                    Religon.Text = "";
                    Religon.BackColor = Color.White;
                    active.Text = "";
                    active.BackColor = Color.White;

                }

            }
            else
            {
                TXTnamesDelete.Text = "";
                arabic.Text = "";
                English.Text = "";
                French.Text = "";
                Science.Text = "";
                Math.Text = "";
                Hist.Text = "";
                Geo.Text = "";
                Religon.Text = "";
                active.Text = "";
            }
        }

        private void Save_Click(object sender, EventArgs e)
        {
            try
            {
                if (arabic.Text == "" || English.Text == "" || French.Text == "" || Science.Text == "" || Math.Text == "" || Hist.Text == "" || Geo.Text == "" || Religon.Text == "" || active.Text == "")
                {
                    DialogResult d = MessageBox.Show("Complete The update Result Please", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error)

                        ;
                    if (d == DialogResult.OK)
                    {
                        TXTnamesDelete.Text = "";
                        arabic.Text = "";
                        arabic.BackColor = Color.White;
                        English.Text = "";
                        English.BackColor = Color.White;
                        French.Text = "";
                        French.BackColor = Color.White;
                        Science.Text = "";
                        Science.BackColor = Color.White;
                        Math.Text = "";
                        Math.BackColor = Color.White;
                        Hist.Text = "";
                        Hist.BackColor = Color.White;
                        Geo.Text = "";
                        Geo.BackColor = Color.White;
                        Religon.Text = "";
                        Religon.BackColor = Color.White;
                        active.Text = "";
                        active.BackColor = Color.White;

                    }



                }
                else
                {
                    float Arab = Convert.ToInt32(arabic.Text);
                    float Englishs = Convert.ToInt32(English.Text);
                    float french = Convert.ToInt32(French.Text);
                    float science = Convert.ToInt32(Science.Text);
                    float mathe = Convert.ToInt32(Math.Text);
                    float historic = Convert.ToInt32(Hist.Text);
                    float geog = Convert.ToInt32(Geo.Text);
                    float Grade = Arab + Englishs + french + science + mathe + historic + geog;
                    DialogResult r = MessageBox.Show("Would you like Update this Date For Student", "Meassage", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (r == DialogResult.Yes)
                    {
                        ConnectionClass c = new ConnectionClass();
                        c.PoolConnection();
                        c.CMD.CommandText = "Update Result set arabic=" + arabic.Text + " where Studentname='" + TXTnamesDelete.Text + "'";
                        ConnectionClass c1 = new ConnectionClass();
                        c1.PoolConnection();
                        c1.CMD.CommandText = "Update Result set english=" + English.Text + " where Studentname='" + TXTnamesDelete.Text + "'";
                        ConnectionClass c2 = new ConnectionClass();
                        c2.PoolConnection();
                        c2.CMD.CommandText = "Update Result set French=" + French.Text + " where Studentname='" + TXTnamesDelete.Text + "'";
                        ConnectionClass c3 = new ConnectionClass();
                        c3.PoolConnection();
                        c3.CMD.CommandText = "Update Result set Science=" + Science.Text + " where Studentname='" + TXTnamesDelete.Text + "'";
                        ConnectionClass c4 = new ConnectionClass();
                        c4.PoolConnection();
                        c4.CMD.CommandText = "Update Result set otherActive=" + active.Text + " where Studentname='" + TXTnamesDelete.Text + "'";
                        ConnectionClass c5 = new ConnectionClass();
                        c5.PoolConnection();
                        c5.CMD.CommandText = "Update Result set Historic=" + Hist.Text + " where Studentname='" + TXTnamesDelete.Text + "'";
                        ConnectionClass c6 = new ConnectionClass();
                        c6.PoolConnection();
                        c6.CMD.CommandText = "Update Result set Geo=" + Geo.Text + " where Studentname='" + TXTnamesDelete.Text + "'";
                        ConnectionClass c7 = new ConnectionClass();
                        c7.PoolConnection();
                        c7.CMD.CommandText = "Update Result set math=" + Math.Text + " where Studentname='" + TXTnamesDelete.Text + "'";
                        ConnectionClass c8 = new ConnectionClass();
                        c8.PoolConnection();
                        c8.CMD.CommandText = "Update Result set religon=" + Religon.Text + " where Studentname='" + TXTnamesDelete.Text + "'";
                        ConnectionClass c9 = new ConnectionClass();
                        c9.PoolConnection();
                        c9.CMD.CommandText = "Update Result set totel=" + Grade + " where Studentname='" + TXTnamesDelete.Text + "'";
                        c.CMD.ExecuteNonQuery();
                        c1.CMD.ExecuteNonQuery();
                        c2.CMD.ExecuteNonQuery();
                        c3.CMD.ExecuteNonQuery();
                        c4.CMD.ExecuteNonQuery();
                        c5.CMD.ExecuteNonQuery();
                        c6.CMD.ExecuteNonQuery();
                        c7.CMD.ExecuteNonQuery();
                        c8.CMD.ExecuteNonQuery();
                        c9.CMD.ExecuteNonQuery();
                        DialogResult d = MessageBox.Show("Date Update Succsfully", "Notice Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        if (d == DialogResult.OK)
                        {
                            TXTnamesDelete.Text = "";
                            arabic.Text = "";
                            arabic.BackColor = Color.White;
                            English.Text = "";
                            English.BackColor = Color.White;
                            French.Text = "";
                            French.BackColor = Color.White;
                            Science.Text = "";
                            Science.BackColor = Color.White;
                            Math.Text = "";
                            Math.BackColor = Color.White;
                            Hist.Text = "";
                            Hist.BackColor = Color.White;
                            Geo.Text = "";
                            Geo.BackColor = Color.White;
                            Religon.Text = "";
                            Religon.BackColor = Color.White;
                            active.Text = "";
                            active.BackColor = Color.White;
                        }
                    }

                    else
                    {
                        TXTnamesDelete.Text = "";
                        arabic.Text = "";
                        English.Text = "";
                        French.Text = "";
                        Science.Text = "";
                        Math.Text = "";
                        Hist.Text = "";
                        Geo.Text = "";
                        Religon.Text = "";
                        active.Text = "";
                    }
                }
            }
            catch { MessageBox.Show("If you Found Problem in Program ,Please tell Me to fix this error"); }
        }
        private void SeachDelete_Click(object sender, EventArgs e)
        {
            ConnectionClass c = new ConnectionClass();
            c.PoolConnection();
            c.CMD.CommandText = "Select Arabic,English,French,Science,Math,Historic,Geo,Religon,OtherActive from Result where StudentName='"+TXTnamesDelete.Text+"'";
            c.DR = c.CMD.ExecuteReader();
            if (c.DR.Read())
            {
                 arabic.Text=c.DR[0].ToString();
                English.Text=c.DR[1].ToString();
                French.Text=c.DR[2].ToString();
                Science.Text=c.DR[3].ToString();
                Math.Text=c.DR[4].ToString();
                Hist.Text=c.DR[5].ToString();
                Geo.Text=c.DR[6].ToString();
                Religon.Text=c.DR[7].ToString();
                active.Text=c.DR[8].ToString();

            }
            else{
                MessageBox.Show("No Student with this name ","Message",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                arabic.Text = "";
                English.Text = "";
                French.Text = "";
                Science.Text = "";
                Math.Text = "";
                Hist.Text = "";
                Geo.Text = "";
                Religon.Text = "";
                active.Text = "";

            
            }

        }

        private void TXTnamesDelete_TextChanged(object sender, EventArgs e)
        {
            AutoCompleteStringCollection ayman = new AutoCompleteStringCollection();

            // listBox1.Show();
            ConnectionClass con = new ConnectionClass();
            con.PoolConnection();
            con.CMD.CommandText = "select studentname from Result where studentname  like +@name+'%'";
            con.CMD.Parameters.Add("@name", SqlDbType.NVarChar, 50).Value = TXTnamesDelete.Text;
            con.DR = con.CMD.ExecuteReader();
            while (con.DR.Read())
            {
                // listBox1.Items.Add(con.DR[0].ToString());
                ayman.Add(con.DR[0].ToString());

            }
            TXTnamesDelete.AutoCompleteMode=    AutoCompleteMode.Suggest;
            TXTnamesDelete.AutoCompleteSource=    AutoCompleteSource.CustomSource;
            TXTnamesDelete.AutoCompleteCustomSource=ayman;
        }

        private void TXTnamesDelete_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && e.KeyChar != ' ')
            {
                e.Handled = true;
            }


            if (e.KeyChar == ' '
                && (sender as TextBox).Text.IndexOf(' ') > -1)
            {
                e.Handled = true;
            }
            
            
        }

        private void otherOperation_Load(object sender, EventArgs e)
        {

        }

        private void arabic_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar)
        && !char.IsDigit(e.KeyChar)
        && e.KeyChar!= '.')
            {
                e.Handled = true;
            }
        }

        private void arabic_TextChanged(object sender, EventArgs e)
        {
           
            try
            {
                float a = Convert.ToInt32(arabic.Text);
                if (a > 100||a<0) {DialogResult d= MessageBox.Show("Update Must be Between 0 to 100","Message",MessageBoxButtons.OK,MessageBoxIcon.Error);
                if (d == DialogResult.OK) { arabic.Text = ""; arabic.BackColor = Color.White; }
                }  
                if (a < 50) { arabic.BackColor = Color.Yellow; }
                else {arabic.BackColor = Color.White; }
            }
            catch { }
        }

        private void English_TextChanged(object sender, EventArgs e)
        {
            try
            {
                float a = Convert.ToInt32(English.Text);
                if (a < 0 || a > 50) { DialogResult d = MessageBox.Show("Update Must be Between 0 to 50", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                if (d == DialogResult.OK) { English.Text = ""; Math.BackColor = Color.White; }
                }
                
                if (a < 25) { English.BackColor = Color.Yellow; }
                else { English.BackColor = Color.White; }
            }
            catch { }

        }

        private void French_TextChanged(object sender, EventArgs e)
        {
            try
            {
                float a = Convert.ToInt32(French.Text);
                if (a < 0 || a > 50) { DialogResult d = MessageBox.Show("Update Must be Between 0 to 50", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);

                if (d == DialogResult.OK) { French.Text = ""; French.BackColor = Color.White; }
                }
                
                if (a < 25) { French.BackColor = Color.Yellow; }
                else { French.BackColor= Color.White; }
            }

            catch { }
        }

        private void Science_TextChanged(object sender, EventArgs e)
        {
            try
            {
                float a = Convert.ToInt32(Science.Text);
                if (a < 0 || a > 50) { DialogResult d = MessageBox.Show("Update Must be Between 0 to 50", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                if (d == DialogResult.OK) { Science.Text = ""; Science.BackColor = Color.White; }
                
                }
                if (a < 25) { Science.BackColor = Color.Yellow; }
                else { Science.BackColor = Color.White; }
            }
            catch { }
        }

        private void Math_TextChanged(object sender, EventArgs e)
        {
            try
            {
                float a = Convert.ToInt32(Math.Text);
                if(a<0||a>100){DialogResult d= MessageBox.Show("Update Must be Between 0 to 100","Message",MessageBoxButtons.OK,MessageBoxIcon.Error);
                if (d == DialogResult.OK) { Math.Text = ""; Math.BackColor = Color.White; }
                
                }
                if (a < 50) { Math.BackColor = Color.Yellow; }
                else { Math.BackColor = Color.White; }
            }
            catch { }
        }

        private void Hist_TextChanged(object sender, EventArgs e)
        {
            try
            {
                float a = Convert.ToInt32(Hist.Text);
                if (a < 0 || a > 25) { DialogResult d = MessageBox.Show("Update Must be Between 0 to 25", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);

                if (d == DialogResult.OK) { Hist.Text = ""; Hist.BackColor = Color.White; }
                }
                if (a < 12) { Hist.BackColor = Color.Yellow; }
                else { Hist.BackColor = Color.White; }
            }
            catch { }
        }


        private void Geo_TextChanged(object sender, EventArgs e)
        {
            try
            {
                float a = Convert.ToInt32(Geo.Text);
                if(a<0||a>25){DialogResult d= MessageBox.Show("Update Must be Between 0 to 25","Message",MessageBoxButtons.OK,MessageBoxIcon.Error);
                if (d == DialogResult.OK) { Geo.Text = ""; Geo.BackColor = Color.White; }
                }

                if (a < 12) { Geo.BackColor = Color.Yellow; }
                else { Geo.BackColor = Color.White; }
            }
            catch { }
        }

        private void Religon_TextChanged(object sender, EventArgs e)
        {
            try
            {
                float a = Convert.ToInt32(Religon.Text);
                if(a<0||a>25){DialogResult d= MessageBox.Show("Update Must be Between 0 to 25","Message",MessageBoxButtons.OK,MessageBoxIcon.Error);
                if (d == DialogResult.OK) { Religon.Text = ""; Religon.BackColor = Color.White; }
                }
                if (a < 12) { Religon.BackColor = Color.Yellow; }
                else { Religon.BackColor
                    = Color.White; }
            }
            catch { }
        }

        private void active_TextChanged(object sender, EventArgs e)
        {
            try
            {
                float a = Convert.ToInt32(active.Text);
                if (a < 0 || a > 20) { DialogResult d = MessageBox.Show("Update Must be Between 0 to 20", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                if (d == DialogResult.OK) { active.Text = ""; active.BackColor = Color.White; }
                }
                if (a < 10) { active.BackColor = Color.Yellow; }
                else { active.BackColor = Color.White; }
            }
            catch { }
        }
        }
    }
