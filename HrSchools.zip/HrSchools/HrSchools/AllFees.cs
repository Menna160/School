﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HrSchools
{
    public partial class AllFees : Form
    {
        DataSet ds = new DataSet();
        public AllFees()
        {
            InitializeComponent();
        }

        private void AllFees_Load(object sender, EventArgs e)
        {
            
            ds.Clear();
            ConnectionClass c = new ConnectionClass();

            c.PoolConnection();
            c.CMD.CommandText = "Select costid,studentname ,costtype,costprice,discount,paidmoney,datepaid,remain from costs";
            c.DA.SelectCommand = c.CMD;
            c.DA.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            ds.Clear();
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            Searchfees s = new Searchfees();
            s.Show();
            this.Hide();
        }

        private void BTNclose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
