﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HrSchools
{
    public partial class Controls : Form
    {
        public Controls()
        {
            InitializeComponent();
        }

        private void Controls_Load(object sender, EventArgs e)
        {
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void BTNStudentData_Click(object sender, EventArgs e)
        {
            StudentControl std = new StudentControl();
            std.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoginProgram l = new LoginProgram();
            l.Show();
            this.Hide();
        }

        private void BTNFees_Click(object sender, EventArgs e)
        {
            FeesControl f = new FeesControl();
            f.Show();
            this.Hide();
        }

        private void BTNControlName_Click(object sender, EventArgs e)
        {
            ResultControl r = new ResultControl();
            r.Show();
            this.Hide();
        }

        private void Backup_Click(object sender, EventArgs e)
        {
            ConnectionClass c = new ConnectionClass();
            c.PoolConnection();

        }
    }
}
