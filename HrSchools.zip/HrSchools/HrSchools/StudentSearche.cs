﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HrSchools
{
    public partial class StudentSearche : Form
    {
        public StudentSearche()
        {
            InitializeComponent();
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            StudentControl s = new StudentControl();
            s.Show();
            this.Hide();
        }

        private void BTNclose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            txtno.Text = "";
            TXTAddress.Text = "";
            TxtSearchstudent.Text = "";
            name.Text = "";
            gender.Text = "";

        }

      

        private void BTNSearch_Click(object sender, EventArgs e)
        {
            AllStudent a = new AllStudent();
            a.Show();
            this.Hide();

           
               

            }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            ConnectionClass cn = new ConnectionClass();
            cn.PoolConnection();
            cn.CMD.CommandText="Select stdid,stdbirthDate,stdAddress,stdgender,stdArrive,classname from Student where stdname=N'"+TxtSearchstudent.Text+"' ";
            cn.DR = cn.CMD.ExecuteReader();
            while (cn.DR.Read())
            {
                txtno.Text = cn.DR[0].ToString();
                StdTime.Text = cn.DR[1].ToString();
                TXTAddress.Text = cn.DR[2].ToString();
                gender.Text = cn.DR[3].ToString();
                dateTimePicker1.Text = cn.DR[4].ToString();
                name.Text = cn.DR[5].ToString();
            
            
            }
                

        }

        private void StudentSearche_Load(object sender, EventArgs e)
        {
        }

        private void Print_Click(object sender, EventArgs e)
        {

        }

        private void TxtSearchstudent_TextChanged(object sender, EventArgs e)
        {
            //AutoCompleteStringCollection ayman = new AutoCompleteStringCollection();

            //// listBox1.Show();
            //ConnectionClass con = new ConnectionClass();
            //con.PoolConnection();
            //con.CMD.CommandText = "select stdname from Student where stdname  like +@name+'%'";
            //con.CMD.Parameters.Add("@name", SqlDbType.NVarChar, 50).Value = TxtSearchstudent.Text;
            //con.DR = con.CMD.ExecuteReader();
            //while (con.DR.Read())
            //{
            //    // listBox1.Items.Add(con.DR[0].ToString());
            //    ayman.Add(con.DR[0].ToString());

            //}
            //TxtSearchstudent.AutoCompleteMode = AutoCompleteMode.Suggest;
            //TxtSearchstudent.AutoCompleteSource = AutoCompleteSource.CustomSource;
            //TxtSearchstudent.AutoCompleteCustomSource = ayman;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void txtno_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsLetter(e.KeyChar)) && !(char.IsWhiteSpace(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        private void gender_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtSearchstudent_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && e.KeyChar != ' ')
            {
                e.Handled = true;
            }


            if (e.KeyChar == ' '
                && (sender as TextBox).Text.IndexOf(' ') > -1)
            {
                e.Handled = true;
            }
            
            
        }

        

        }
    }

