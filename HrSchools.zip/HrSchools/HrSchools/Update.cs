﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HrSchools
{
    public partial class Update : Form
    {
        public Update()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            StudentControl s = new StudentControl();
            s.Show();
            this.Hide();
        }

        private void Update_Load(object sender, EventArgs e)
        {//
           

        }

        private void BTNclose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            Txtno.Text = "";
           // TXTName.Text = "";
           // comboGender.Text = "Enter your Gender";
            ComboStd.Text = "Enter your Class Stage";
            TXTAddress.Text = "";
            TXTnamesearch.Text="";
            TXTClassno.Text = "";
        }

        private void searchUpdate_Click(object sender, EventArgs e)
        {
            ConnectionClass cn = new ConnectionClass();
            cn.PoolConnection();
            cn.CMD.CommandText = "Select stdid,classname,Stdaddress from Student where stdname= '" +TXTnamesearch.Text+"'";
            cn.DR = cn.CMD.ExecuteReader();
            if (cn.DR.Read())
            {
                Txtno.Text = cn.DR[0].ToString();
            
                TXTAddress.Text = cn.DR[2].ToString();
                TXTClassno.Text = cn.DR[1].ToString();
                
            }
        }

        private void BTNUpdate_Click(object sender, EventArgs e)
        {
            if (TXTnamesearch.Text == "")
            {
                MessageBox.Show("Enter name to search");
            }
            else
            {
                DialogResult r2 = MessageBox.Show("Would You need Change Data", "message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (r2 == DialogResult.Yes)
                {
                    ConnectionClass cn = new ConnectionClass();

                    cn.PoolConnection();
                    cn.CMD.CommandText = "Update Student  set stdAddress='" + TXTAddress.Text + "'  where stdname='" + TXTnamesearch.Text + "'";
                    cn.CMD.ExecuteNonQuery();
                    // cn.CMD.CommandText = "Update Student  set stdname='" + TXTName.Text + "'  where stdname='" + TXTnamesearch.Text + "'";
                    ConnectionClass cn1 = new ConnectionClass();

                    cn1.PoolConnection();
                    cn1.CMD.CommandText = "Update Student  set stdid=" + Txtno.Text + "  where stdname='" + TXTnamesearch.Text + "'";
                    cn1.CMD.ExecuteNonQuery();
                    ConnectionClass cn2 = new ConnectionClass();
                    cn2.PoolConnection();
                    cn2.CMD.CommandText = "Update Student  set classname ='" + ComboStd.SelectedItem + "'  where stdname='" + TXTnamesearch.Text + "'";
                    cn2.CMD.ExecuteNonQuery();
                }
                else
                {

                    TXTAddress.Text = "";
                    TXTClassno.Text = "";
                    TXTnamesearch.Text = "";
                    // TXTName.Text = "";
                    Txtno.Text = "";
                    ComboStd.Text = "Select Stage from  Here";
                }
                // cn.CMD.CommandText = "Update Student  set stdAddress='" + .Text + "'  where stdname='" + TXTnamesearch.Text + "'";
                DialogResult d = MessageBox.Show("Changed Data for Student", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                if (d == DialogResult.OK)
                {
                    TXTAddress.Text = "";
                    TXTClassno.Text = "";
                    TXTnamesearch.Text = "";
                    // TXTName.Text = "";
                    Txtno.Text = "";
                    ComboStd.Text = "Select Stage from  Here";
                }

                else
                {
                    StudentControl s = new StudentControl();
                    s.Show();
                    this.Hide();

                }
            }
        }

        private void ComboStd_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void TXTnamesearch_TextChanged(object sender, EventArgs e)
        {
            AutoCompleteStringCollection ayman = new AutoCompleteStringCollection();

           // listBox1.Show();
            ConnectionClass con = new ConnectionClass();
            con.PoolConnection();
            con.CMD.CommandText = "select stdname from Student where stdname  like +@name+'%'";
            con.CMD.Parameters.Add("@name", SqlDbType.NVarChar, 50).Value = TXTnamesearch.Text;
            con.DR = con.CMD.ExecuteReader();
            while (con.DR.Read())
            {
               // listBox1.Items.Add(con.DR[0].ToString());
                ayman.Add(con.DR[0].ToString());
                    
            }
            TXTnamesearch.AutoCompleteMode = AutoCompleteMode.Suggest;
            TXTnamesearch.AutoCompleteSource = AutoCompleteSource.CustomSource;
            TXTnamesearch.AutoCompleteCustomSource = ayman;
            
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
          
        }

        private void TXTnamesearch_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void TXTName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && e.KeyChar != ' ')
            {
                e.Handled = true;
            }


            if (e.KeyChar == ' '
                && (sender as TextBox).Text.IndexOf(' ') > -1)
            {
                e.Handled = true;
            }
            
            
            }
        }
    }

