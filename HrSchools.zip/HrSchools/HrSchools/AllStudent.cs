﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace HrSchools
{
     
    public partial class AllStudent : Form
    {
        BindingSource bs = new BindingSource();
        DataSet ds = new DataSet();

        public AllStudent()
        {
            InitializeComponent();
        }

        private void AllStudent_Load(object sender, EventArgs e)
        {
            
        }

        private void BTNSearch_Click(object sender, EventArgs e)
        {
            StudentSearche s=new StudentSearche ();
            s.Show();
            this.Hide();
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            StudentSearche s = new StudentSearche();
            s.Show();
            this.Hide();

        }

        private void BTNclose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            ds.Clear();
            ConnectionClass cn = new ConnectionClass();
            cn.PoolConnection();
            cn.DA.SelectCommand =new SqlCommand ("Select Stdid as 'Student Number',Stdname as 'Student name',stdGender as 'Gender',StdBirthdate as 'BirthDate',stdArrive as 'Date Acvieve in School',Classname as 'Class Names' from Student where Classname='"+comboBox1.SelectedItem+"'",cn.Conn);
            cn.DA.SelectCommand.ExecuteNonQuery();
            cn.DA.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
           
        }
    }
}
