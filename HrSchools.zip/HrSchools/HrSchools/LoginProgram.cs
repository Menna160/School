﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HrSchools
{
    public partial class LoginProgram : Form
    {
        public LoginProgram()
        {
            InitializeComponent();
        }

        private void LoginProgram_Load(object sender, EventArgs e)
        {
            MainProgram m = new MainProgram();
            m.Show();
        }









        private void BTNClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void BTNLogin_Click(object sender, EventArgs e)
        {
            if (TXTUsername.Text == "" || TXTPassword.Text == "")
            { MessageBox.Show("You Must Enter You UserName And Password Correctly Method", "Error Message", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error); }


            ConnectionClass c = new ConnectionClass();
            c.PoolConnection();
           
            c.CMD.CommandText = "Select userid,username from users where userid='" + TXTUsername.Text + "' and username='" + TXTPassword.Text + "'";
            c.DR = c.CMD.ExecuteReader();
            if (c.DR.Read())
            {
                string x = c.DR[0].ToString();
                string y = c.DR[1].ToString();
                if (x == "admin" && y == "admin")
                {
                    Controls s = new Controls();
                     
                    s.Show();
                    this.Hide();

                }
                else if (x == "Control Room" && y == "Control")
                {

                    Control_Room c1 = new Control_Room();
                    c1.Show();
                    this.Hide();

                   

                }
                else if (x == "User" && y == "User")
                {
                    usercontrol s = new usercontrol();

                    s.Show();
                    this.Hide();
                }
            }
                else 
                {
                    
               DialogResult s= MessageBox.Show("You Are Not Memeber In My Programe ,Please Check User name and Password ","Error Message",MessageBoxButtons.RetryCancel,MessageBoxIcon.Warning);
               if (s == DialogResult.Retry) { LoginProgram l = new LoginProgram(); l.Show(); this.Hide(); }
               else { Application.Exit(); }


                }
                
                }
            }
        }
    

