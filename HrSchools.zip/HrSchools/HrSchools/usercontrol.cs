﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HrSchools
{
    public partial class usercontrol : Form
    {
        public usercontrol()
        {
            InitializeComponent();
        }

        private void StudentBtn_Click(object sender, EventArgs e)
        {
            StudentControl std = new StudentControl();
            std.Show();
            this.Hide();
        }

        private void FeesBtn_Click(object sender, EventArgs e)
        {
            FeesControl f = new FeesControl();
            f.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoginProgram l = new LoginProgram();
            l.Show();
            this.Hide();
        }
    }
}
