﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HrSchools
{
    public partial class Searchfees : Form
    {
        public Searchfees()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void BTNclose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            FeesControl f = new FeesControl();
            f.Show(); this.Hide();
        }

        private void Searchfees_Load(object sender, EventArgs e)
        {
           
        }

        private void SeachDelete_Click(object sender, EventArgs e)
        {
            ConnectionClass c = new ConnectionClass();
            c.PoolConnection();
            c.CMD.CommandText = "Select costid,costtype,costprice,discount,paidmoney,datepaid,remain,studentname from costs where studentname='"+TXTnamesDelete.Text+"'";
            c.DR = c.CMD.ExecuteReader();
            if (c.DR.Read())
            {
                costnumber.Text = c.DR[0].ToString();
                costtype.Text = c.DR[1].ToString();
                costprice.Text = c.DR[2].ToString();
                Discount.Text = c.DR[3].ToString();
                Paidmoney.Text = c.DR[4].ToString();
                Dateofpaid.Text = c.DR[5].ToString();
                Remain.Text = c.DR[6].ToString();
                studentname.Text = c.DR[7].ToString();

            }
            else {DialogResult r= MessageBox.Show("This student not Paid the Fees of Schools want to add cost","message",MessageBoxButtons.OK,MessageBoxIcon.Information);
            if (r == DialogResult.OK)
            {
                insertfees f = new insertfees();
                f.Show();
                this.Hide();
            
            }
            }

        }

        private void TXTnamesDelete_TextChanged(object sender, EventArgs e)
        {
            AutoCompleteStringCollection ayman = new AutoCompleteStringCollection();

            // listBox1.Show();
            ConnectionClass con = new ConnectionClass();
            con.PoolConnection();
            con.CMD.CommandText = "select studentname from costs where studentname  like +@name+'%'";
            con.CMD.Parameters.Add("@name", SqlDbType.NVarChar, 50).Value = TXTnamesDelete.Text;
            con.DR = con.CMD.ExecuteReader();
            while (con.DR.Read())
            {
                // listBox1.Items.Add(con.DR[0].ToString());
                ayman.Add(con.DR[0].ToString());

            }
            TXTnamesDelete.AutoCompleteMode= AutoCompleteMode.Suggest;
            TXTnamesDelete.AutoCompleteSource=  AutoCompleteSource.CustomSource;
            TXTnamesDelete.AutoCompleteCustomSource=ayman;
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            costprice.Text = "";
            costnumber.Text = "";
            costtype.Text = "";
            Paidmoney.Text = "";
            TXTnamesDelete.Text = "";
            Remain.Text = "";
            Discount.Text="";
            Dateofpaid.Text = "";
            studentname.Text = "";

        }

        private void Save_Click(object sender, EventArgs e)
        {
            AllFees a = new AllFees();
            a.Show();
            this.Hide();
        }

        private void TXTnamesDelete_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && e.KeyChar != ' ')
            {
                e.Handled = true;
            }


            if (e.KeyChar == ' '
                && (sender as TextBox).Text.IndexOf(' ') > -1)
            {
                e.Handled = true;
            }
            
            
        }

        private void TXTnamesDelete_TextChanged_1(object sender, EventArgs e)
        {
            AutoCompleteStringCollection ayman = new AutoCompleteStringCollection();

            // listBox1.Show();
            ConnectionClass con = new ConnectionClass();
            con.PoolConnection();
            con.CMD.CommandText = "select studentname from costs where studentname  like +@name+'%'";
            con.CMD.Parameters.Add("@name", SqlDbType.NVarChar, 50).Value = TXTnamesDelete.Text;
            con.DR = con.CMD.ExecuteReader();
            while (con.DR.Read())
            {
                // listBox1.Items.Add(con.DR[0].ToString());
                ayman.Add(con.DR[0].ToString());

            }
            TXTnamesDelete.AutoCompleteMode = AutoCompleteMode.Suggest;
            TXTnamesDelete.AutoCompleteSource = AutoCompleteSource.CustomSource;
            TXTnamesDelete.AutoCompleteCustomSource = ayman;
        }

        private void SeachDelete_Click_1(object sender, EventArgs e)
        {
            ConnectionClass c = new ConnectionClass();
            c.PoolConnection();
            c.CMD.CommandText = "Select costid,costtype,costprice,discount,paidmoney,datepaid,remain,studentname from costs where studentname='" + TXTnamesDelete.Text + "'";
            c.DR = c.CMD.ExecuteReader();
            if (c.DR.Read())
            {
                costnumber.Text = c.DR[0].ToString();
                costtype.Text = c.DR[1].ToString();
                costprice.Text = c.DR[2].ToString();
                Discount.Text = c.DR[3].ToString();
                Paidmoney.Text = c.DR[4].ToString();
                Dateofpaid.Text = c.DR[5].ToString();
                Remain.Text = c.DR[6].ToString();
                studentname.Text = c.DR[7].ToString();

            }
            else
            {
                DialogResult r = MessageBox.Show("This student not Paid the Fees of Schools want to add cost", "message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                if (r == DialogResult.OK)
                {
                    insertfees f = new insertfees();
                    f.Show();
                    this.Hide();

                }
            }
        }


        }
    }
