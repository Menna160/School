﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HrSchools
{
    public partial class Search : Form
    {
        public Search()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void InsertStudent_Load(object sender, EventArgs e)
        {
            MainProgram m = new MainProgram();
            m.Show();
        }

        private void BTNclose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            StudentControl s = new StudentControl();
            s.Show();
            this.Hide();
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void BTNsearchname_Click(object sender, EventArgs e)
        {

        }
    }
}
