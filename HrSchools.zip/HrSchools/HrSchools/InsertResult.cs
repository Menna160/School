﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HrSchools
{
    public partial class InsertResult : Form
    {
        public InsertResult()
        {
            InitializeComponent();
        }

        private void Save_Click(object sender, EventArgs e)
        {
                if (txtfre.Text == "" || act.Text == "" || FRe.Text == "" || arbic.Text == "" || math.Text == "" || Eng.Text == "" || geo.Text == "" || his.Text == "" || rel.Text == "")
                { MessageBox.Show("Please Enter Grade of this Student Here", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error); }
                int a = Convert.ToInt32(textBox1.Text);
                float Arab = Convert.ToInt32(arbic.Text);
                float English = Convert.ToInt32(Eng.Text);
                float french = Convert.ToInt32(FRe.Text);
                float science = Convert.ToInt32(txtfre.Text);
                float mathe = Convert.ToInt32(math.Text);
                float historic = Convert.ToInt32(his.Text);
                float geog = Convert.ToInt32(geo.Text);
                float religon = Convert.ToInt32(rel.Text);
                float otherActive = Convert.ToInt32(act.Text);
                float Grade = Arab + English + french + science + mathe + historic + geog;
                DialogResult r = MessageBox.Show("Would you Like Add this Information", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (r == DialogResult.Yes)
                {
                    ConnectionClass c = new ConnectionClass();
                    c.PoolConnection();
                    c.CMD.CommandText = "Insert into Result(Fkstdid,Arabic,English,French,Science,Math,Historic,Geo,Religon,otherActive,Totel,Studentname,Stage,Classid) values(" + a + "," + Arab + "," + English + "," + french + "," + science + "," + mathe + "," + historic + "," + geog + "," + religon + "," + otherActive + "," + Grade + ",'" + txtno.Text + "','" + textBox2.Text + "','" + textBox3.Text + "')";
                      c.CMD.ExecuteNonQuery();
                    DialogResult w = MessageBox.Show("Data Saved ", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    if (w == DialogResult.OK)
                    {

                        txtfre.Text = "";
                        txtfre.BackColor = Color.White;
                        act.Text = "";
                        act.BackColor = Color.White;
                        FRe.Text = "";
                        FRe.BackColor = Color.White;
                        arbic.Text = "";
                        arbic.BackColor = Color.White;
                        math.Text = "";
                        math.BackColor = Color.White;
                        Eng.Text = "";
                        Eng.BackColor = Color.White;
                        geo.Text = "";
                        geo.BackColor = Color.White;
                        his.Text = "";
                        his.BackColor = Color.White;
                        // total.Text = "0";
                        rel.Text = "";
                        rel.BackColor = Color.White;
                        //comboBox1.Text = "Select Class number";
                        textBox2.Text = "";
                        textBox3.Text = "";
                        textBox1.Text = "";
                        txtno.Text = "";


                    }
                }
                else
                {

                    txtfre.Text = "";
                    act.Text = "";
                    FRe.Text = "";
                    arbic.Text = "";
                    math.Text = "";
                    Eng.Text = "";
                    geo.Text = "";
                    his.Text = "";
                    // total.Text = "0";
                    rel.Text = "";
                }
           
        }

        private void InsertResult_Load(object sender, EventArgs e)
        {
            groupBox1.Enabled = false;



        }

        private void txtno_TextChanged(object sender, EventArgs e)
        {

            AutoCompleteStringCollection ayman = new AutoCompleteStringCollection();

            // listBox1.Show();
            ConnectionClass con = new ConnectionClass();
            con.PoolConnection();
            con.CMD.CommandText = "select stdname from Student where stdname  like +@name+'%'";
            con.CMD.Parameters.Add("@name", SqlDbType.NVarChar, 50).Value = txtno.Text;
            con.DR = con.CMD.ExecuteReader();
            while (con.DR.Read())
            {
                // listBox1.Items.Add(con.DR[0].ToString());
                ayman.Add(con.DR[0].ToString());

            }
            txtno.AutoCompleteMode = AutoCompleteMode.Suggest;
            txtno.AutoCompleteSource = AutoCompleteSource.CustomSource;
            txtno.AutoCompleteCustomSource = ayman;
            //searche for  Student id
           
                // int a = Convert.ToInt32(textBox1.Text);
                ConnectionClass c = new ConnectionClass();
                c.PoolConnection();
                c.CMD.CommandText = "Select Stdid,classname from Student where stdname='" + txtno.Text + "'";
                c.DR = c.CMD.ExecuteReader();
                if (c.DR.Read())
                {
                    textBox1.Text = c.DR[0].ToString();
                    textBox2.Text = c.DR[1].ToString();
                    //textBox3.Text = c.DR[2].ToString();

                }
                else
                {
                    textBox1.Text = "";
                    txtfre.Enabled = false;
                    act.Enabled = false;
                    FRe.Enabled = false;
                    arbic.Enabled = false;
                    math.Enabled = false;
                    Eng.Enabled = false;
                    geo.Enabled = false;
                    his.Enabled = false;
                    //   total.Enabled = false;
                    rel.Enabled = false;
                    textBox3.Text = "";
                    textBox2.Text = "";
                }

            
        
        }

        private void BTNclose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            ResultControl r = new ResultControl();
            r.Show();
            this.Hide();
            
        }

        private void arbic_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void Eng_KeyPress(object sender, KeyPressEventArgs e)
        {
          //  e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
            if (Char.IsDigit(e.KeyChar) || e.KeyChar == '\b' || e.KeyChar == '.')
            {
                // Allow Digits and BackSpace char
            }
        }

        private void FRe_KeyPress(object sender, KeyPressEventArgs e)
        {
           // e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
            if (Char.IsDigit(e.KeyChar) || e.KeyChar == '\b' || e.KeyChar == '.')
            {
                // Allow Digits and BackSpace char
            }
            
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
                  txtfre.Text = "";
            act.Text = "";
            FRe.Text = "";
            arbic.Text = "";
            math.Text = "";
            Eng.Text = "";
            geo.Text = "";
            his.Text = "";
            // total.Text = "0";
            rel.Text = "";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int a = Convert.ToInt32(textBox1.Text);
                ConnectionClass c = new ConnectionClass();
                c.PoolConnection();
                c.CMD.CommandText = "Select Stdname,classname from student where stdid=" + a + "";
                c.DR = c.CMD.ExecuteReader();
                if (c.DR.Read())
                {

                    txtno.Text = c.DR[0].ToString();
                    textBox2.Text = c.DR[1].ToString();

                }
                else
                {
                    groupBox1.Enabled = false;
                    txtno.Text = "";
                    txtfre.Enabled = false;
                    act.Enabled = false;
                    FRe.Enabled = false;
                    arbic.Enabled = false;
                    math.Enabled = false;
                    Eng.Enabled = false;
                    geo.Enabled = false;
                    his.Enabled = false;
                    //total.Enabled = false;
                    rel.Enabled = false;
                    textBox2.Text = "";
                    textBox3.Text = "";
                    textBox1.Text = "";
                }

            }
            catch { }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtno.Text == "" && textBox1.Text == "")
                {
                    MessageBox.Show("Enter Student Secret number and Student name", "Message", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                ConnectionClass c = new ConnectionClass();
                c.PoolConnection();
                c.CMD.CommandText = "select Studentname,fkstdid from Result where Studentname='" + txtno.Text + "' and fkstdid=" + textBox1.Text + "";
                c.DR = c.CMD.ExecuteReader();
                if (c.DR.Read())
                {
                    DialogResult r = MessageBox.Show("You are enter result for this Student before Are You need to Update this Result", "Message Notice", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (r == DialogResult.Yes)
                    {
                        otherOperation S = new otherOperation();
                        S.Show();
                        this.Hide();

                    }

                }
                else
                {

                    MessageBox.Show("Now Enter Result Please Attention for enterd Data","Message");
                    groupBox1.Enabled = true;

                    txtfre.Enabled = true;
                    act.Enabled = true;
                    FRe.Enabled = true;
                    arbic.Enabled = true;
                    math.Enabled = true;
                    Eng.Enabled = true;
                    geo.Enabled = true;
                    his.Enabled = true;
                    // total.Enabled = false;
                    rel.Enabled = true;

                }

            }
            catch { }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            ConnectionClass c = new ConnectionClass();
            c.PoolConnection();
            c.CMD.CommandText = "select ClassId from Class where Classnaame='" + textBox2.Text + "'";
            c.DR = c.CMD.ExecuteReader();
            while (c.DR.Read())
            {
                textBox3.Text = c.DR[0].ToString();
            }
        }

        private void arbic_TextChanged(object sender, EventArgs e)
        {
            try
            {
                float a = Convert.ToInt32(arbic.Text);
                if (a > 100 || a < 0)
                {
                    DialogResult d = MessageBox.Show("Enter Grade Between 0 to100", "Message", MessageBoxButtons.OK, MessageBoxIcon.Question);
                    if (d == DialogResult.OK)
                    { arbic.Text = ""; }
                    
                }
                if (a < 50)
                {
                    arbic.BackColor = Color.Yellow;

                }
                else { arbic.BackColor = Color.White; }
                
                 
                
            }
            catch { }
        }

        private void Eng_TextChanged(object sender, EventArgs e)
        {
            try
            {
                float a = Convert.ToInt32(Eng.Text);
                if (a > 50 || a < 0)
                {
                    DialogResult d = MessageBox.Show("Enter Grade Between 0 to 50", "Message", MessageBoxButtons.OK, MessageBoxIcon.Question);
                    if (d == DialogResult.OK)
                    { Eng.Text = ""; }
                }
                if (a < 25)
                {
                    Eng.BackColor= Color.Yellow;

                }
                else {Eng.BackColor = Color.White; }



            }
            catch { }
        }

        private void FRe_TextChanged(object sender, EventArgs e)
        {
            try
            {
                float a = Convert.ToInt32(FRe.Text);
                if (a > 50 || a < 0)
                {
                    DialogResult d = MessageBox.Show("Enter Grade Between 0 to 50", "Message", MessageBoxButtons.OK, MessageBoxIcon.Question);
                    if (d == DialogResult.OK)
                    { FRe.Text = ""; }
                }
                if (a <25)
                {
                    FRe.BackColor= Color.Yellow;

                }
                else { FRe.BackColor = Color.White; }


            }
            catch { }
        }

        private void txtfre_TextChanged(object sender, EventArgs e)
        {
            try
            {
                float a = Convert.ToInt32(txtfre.Text);
                if (a > 50 || a < 0)
                {
                    DialogResult d = MessageBox.Show("Enter Grade Between 0 to 50", "Message", MessageBoxButtons.OK, MessageBoxIcon.Question);
                    if (d == DialogResult.OK)
                    {txtfre.Text = ""; }
                }
                if (a < 25)
                {
                    txtfre.BackColor = Color.Yellow;

                }
                else { txtfre.BackColor= Color.White; }



            }
            catch { }
        }

        private void math_TextChanged(object sender, EventArgs e)
        {
            try
            {
                float a = Convert.ToInt32(math.Text);
                if (a > 100 || a < 0)
                {
                    DialogResult d = MessageBox.Show("Enter Grade Between 0 to 100", "Message", MessageBoxButtons.OK, MessageBoxIcon.Question);
                    if (d == DialogResult.OK)
                    { math.Text = ""; }
                }
                if (a < 50)
                {
                   math.BackColor = Color.Yellow;

                }
                else { math.BackColor = Color.White; }


            }
            catch { }
        }

        private void his_TextChanged(object sender, EventArgs e)
        {
            try
            {
                float a = Convert.ToInt32(his.Text);
                if (a > 25 || a < 0)
                {
                    DialogResult d = MessageBox.Show("Enter Grade Between 0 to 25", "Message", MessageBoxButtons.OK, MessageBoxIcon.Question);
                    if (d == DialogResult.OK)
                    { his.Text = ""; }
                }
                if (a < 12)
                {
                   his.BackColor = Color.Yellow;

                }
                else { his.BackColor = Color.White; }



            }
            catch { }
        }

        private void geo_TextChanged(object sender, EventArgs e)
        {
            try
            {
                float a = Convert.ToInt32(geo.Text);
                if (a > 25 || a < 0)
                {
                    DialogResult d = MessageBox.Show("Enter Grade Between 0 to 25", "Message", MessageBoxButtons.OK, MessageBoxIcon.Question);
                    if (d == DialogResult.OK)
                    { geo.Text = ""; }
                }
                if (a < 12)
                {
                    geo.BackColor= Color.Yellow;

                }
                else { geo.BackColor = Color.White; }



            }
            catch { }
        }

        private void rel_TextChanged(object sender, EventArgs e)
        {
            try
            {
                float a = Convert.ToInt32(rel.Text);
                if (a > 25 || a < 0)
                {
                    DialogResult d = MessageBox.Show("Enter Grade Between 0 to 25","Message",MessageBoxButtons.OK,MessageBoxIcon.Question);
                    if (d == DialogResult.OK)
                    { rel.Text="";}
                }

                if (a < 12)
                {
                    rel.BackColor = Color.Yellow;

                }
                else { rel.BackColor = Color.White; }


            }
            catch { }
        }

        private void act_TextChanged(object sender, EventArgs e)
        {
            try
            {
                float a = Convert.ToInt32(act.Text);
                if (a > 20 || a < 0)
                {
                    DialogResult d = MessageBox.Show("Enter Grade Between 0 to20", "Message", MessageBoxButtons.OK, MessageBoxIcon.Question);
                    if (d == DialogResult.OK)
                    { act.Text = ""; }
                }
                if (a < 10)
                {
                    act.BackColor = Color.Yellow;

                }
                else { act.BackColor = Color.White; }



            }
            catch { }
        }

        private void arbic_KeyPress_1(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            { e.Handled = true; }
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.')>-1)
            { e.Handled = true; }
        }

        private void txtno_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && e.KeyChar != ' ')
            {
                e.Handled = true;
            }


            if (e.KeyChar == ' '
                && (sender as TextBox).Text.IndexOf(' ') > -1)
            {
                e.Handled = true;
            }
            
            
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsLetter(e.KeyChar)) && !(char.IsWhiteSpace(e.KeyChar)))
            {
                e.Handled = true;
            }
            
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
       
        
    }

