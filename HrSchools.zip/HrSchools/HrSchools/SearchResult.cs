﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HrSchools
{
    public partial class SearchResult : Form
    {
        DataSet ds = new DataSet();
        public SearchResult()
        {
            InitializeComponent();
        }

        private void TXTSTDNO_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void BTNSearch_Click(object sender, EventArgs e)
        {
            SearchResult s = new SearchResult();
            s.Show();
            this.Hide();
        }
        
        private void SearchResult_Load(object sender, EventArgs e)
        {

            //ds.Clear();
            //ConClass c = new ConClass();

            //c.PoolConnection();
            //c.CMD.CommandText = "Select Fkstdid as 'StudentNumber',Studentname as'Student Name',Arabic,English,French,Math,Science,Historic,Geo as 'Geogrirphy',Totel as 'Totel Grade',Religon   from Result";
            //c.DA.SelectCommand = c.CMD;
            //c.DA.Fill(ds);
            //dataGridView1.DataSource = ds.Tables[0];
            
        }

        private void BTNclose_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            ResultControl r = new ResultControl();
            r.Show();
            this.Hide();
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            ds.Clear();
        }

       

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            //ds.Clear();
            //ConClass c = new ConClass();

            //c.PoolConnection();
            //c.CMD.CommandText = "Select Fkstdid as 'StudentNumber',Studentname as'Student Name',Arabic,English,French,Math,Science,Historic,Geo as 'Geogrirphy',Totel as 'Totel Grade',Religon   from Result where classid='"+comboBox2.SelectedItem+"' ";
            //c.DA.SelectCommand = c.CMD;
            //c.DA.Fill(ds);
            //dataGridView1.DataSource = ds.Tables[0];
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            ds.Clear();
            ConnectionClass c = new ConnectionClass();

            c.PoolConnection();
            c.CMD.CommandText = "Select Fkstdid as 'StudentNumber',Studentname as'Student Name',Arabic,English,French,Math,Science,Historic,Geo as 'Geogrirphy',Totel as 'Totel Grade',Religon   from Result where stage='" + comboBox1.SelectedItem + "' ";
            c.DA.SelectCommand = c.CMD;
            c.DA.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }
    }
}
