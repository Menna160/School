﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace HrSchools
{
    public class ConnectionClass
    {
        public SqlConnection Conn = new SqlConnection();
        public SqlCommand CMD = new SqlCommand();
        public SqlDataReader DR;
        public SqlDataAdapter DA = new SqlDataAdapter();

        public void PoolConnection()
        {
            try { Conn.Close(); }
            catch (Exception) { throw; } 
        Conn.ConnectionString = @"Data Source=localhost;Initial Catalog=Schools;Integrated Security=True";
            Conn.Open();
            CMD.Connection = Conn;

        }

    }
}