﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HrSchools
{
    public partial class FeesOpreation : Form
    {
        public FeesOpreation()
        {
            InitializeComponent();
        }



        private void BTNclose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtnae_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void FeesOpreation_Load(object sender, EventArgs e)
        {
           
        }



        private void BtnClear_Click(object sender, EventArgs e)
        {
            DateofPaid.Text = "";
            StudentName.Text = "";
            Paid.Text = "";
            Cost.Text = "";
            Costprice.Text = "";
            Remain.Text = "";
            PaidType.Text = "";
            Search.Text = "";
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            FeesControl f = new FeesControl();
            f.Show();
            this.Hide();
        }

        private void TXTname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && e.KeyChar != ' ')
            {
                e.Handled = true;
            }


            if (e.KeyChar == ' '
                && (sender as TextBox).Text.IndexOf(' ') > -1)
            {
                e.Handled = true;
            }
            
            
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar < 65 || e.KeyChar > 122)
            {
                e.Handled = true;
            }
        }

        private void txttype_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar < 65 || e.KeyChar > 122)
            {
                e.Handled = true;
            }
        }

        private void TXTcost_TextChanged(object sender, EventArgs e)
        {

        }

        private void TXTcost_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar)
        && !char.IsDigit(e.KeyChar)
        && e.KeyChar != '.')
            {
                e.Handled = true;
            }
        }

        private void txtremain_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar)
        && !char.IsDigit(e.KeyChar)
        && e.KeyChar != '.')
            {
                e.Handled = true;
            }
        }

        private void Search_TextChanged(object sender, EventArgs e)
        {
            AutoCompleteStringCollection ayman = new AutoCompleteStringCollection();

            // listBox1.Show();
            ConnectionClass con = new ConnectionClass();
            con.PoolConnection();
            con.CMD.CommandText = "select studentname from costs where studentname  like +@name+'%'";
            con.CMD.Parameters.Add("@name", SqlDbType.NVarChar, 50).Value = Search.Text;
            con.DR = con.CMD.ExecuteReader();
            while (con.DR.Read())
            {
                // listBox1.Items.Add(con.DR[0].ToString());
                ayman.Add(con.DR[0].ToString());

            }
            Search.AutoCompleteMode = AutoCompleteMode.Suggest;
            Search.AutoCompleteSource = AutoCompleteSource.CustomSource;
            Search.AutoCompleteCustomSource = ayman;
            DateofPaid.Text = "";
            StudentName.Text = "";
            Paid.Text = "";
            Cost.Text = "";
            Costprice.Text = "";
            Remain.Text = "";
            PaidType.Text = "";
            
        }

        private void SeachOpreation_Click(object sender, EventArgs e)
        {

            ConnectionClass c = new ConnectionClass();
            c.PoolConnection();
            c.CMD.CommandText = "select costID,CostType,CostPrice,Discount,PaidMoney,Datepaid,Remain,StudentName from costs where StudentName ='" + Search.Text + "'";
            c.DR = c.CMD.ExecuteReader();
            if (c.DR.Read())
            {
                Cost.Text = c.DR[0].ToString();
                PaidType.Text = c.DR[1].ToString();
                Costprice.Text = c.DR[2].ToString();
                Discount.Text = c.DR[3].ToString();
                Paid.Text = c.DR[4].ToString();
                DateofPaid.Text = c.DR[5].ToString();
                Remain.Text = c.DR[6].ToString();
                StudentName.Text = c.DR[7].ToString();

            }
            else { MessageBox.Show("No Student with this name","Message"); }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult d = MessageBox.Show("Would you like Delete this Date", "Notice Message", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (d == DialogResult.Yes)
            {
                ConnectionClass c = new ConnectionClass();
                c.PoolConnection();
                c.CMD.CommandText = "delete from Costs where Studentname ='" + Search.Text + "'";
                c.CMD.ExecuteNonQuery();
                DialogResult r = MessageBox.Show("Deleted Succesfully Date", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                if (r == DialogResult.OK)
                {
                    PaidType.Text = "";
                    DateofPaid.Text = "";
                    StudentName.Text = "";
                    Search.Text = "";
                    Remain.Text = "";
                    Cost.Text = "";
                    Costprice.Text = "";
                    Paid.Text = "";
                    Discount.Text = "";

                }
            }
            else
            {

                PaidType.Text = "";
                DateofPaid.Text = "";
                StudentName.Text = "";
                Search.Text = "";
                Remain.Text = "";
                Cost.Text = "";
                Costprice.Text = "";
                Discount.Text = "";
                Paid.Text = "";
            }
        }

        private void Updateme_Click(object sender, EventArgs e)
        {
            DialogResult d = MessageBox.Show("Would you Like to Change data ", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (d == DialogResult.Yes)
            {
                ConnectionClass c = new ConnectionClass();
                c.PoolConnection();
                c.CMD.CommandText = "Update costs set paidmoney =" + Paid.Text + " where studentname='" + Search.Text + "'";
                c.CMD.ExecuteNonQuery();
                ConnectionClass c1 = new ConnectionClass();
                c1.PoolConnection();
                c1.CMD.CommandText = "Update costs set remain =" + Remain.Text + " where studentname='" + Search.Text + "'";
                c1.CMD.ExecuteNonQuery();
                DialogResult r = MessageBox.Show("Message Updated Succesfully", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                if (r == DialogResult.OK)
                {
                    PaidType.Text = "";
                    DateofPaid.Text = "";
                    StudentName.Text = "";
                    Search.Text = "";
                    Remain.Text = "";
                    Cost.Text = "";
                    Costprice.Text = "";
                    Discount.Text = "";

                }
            }
            else
            {
                PaidType.Text = "";
                DateofPaid.Text = "";
                StudentName.Text = "";
                Search.Text = "";
                Remain.Text = "";
                Cost.Text = "";
                Costprice.Text = "";
                Discount.Text = "";
            }
        }

        private void Paid_TextChanged(object sender, EventArgs e)
        {
            try
            {
                float x = Convert.ToInt32(Paid.Text);
                float y = Convert.ToInt32(Costprice.Text);
                if (y > x)
                {
                    float z = y - x;
                    Remain.Text = z.ToString();
                }
                else { MessageBox.Show("Remain must be less than Costprice", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
            }
            catch { }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                float a = Convert.ToInt32(Paid.Text);
                float x = Convert.ToInt32(textBox1.Text);
                float y = Convert.ToInt32(Remain.Text);
                if (y >= x)
                {
                    float z = y - x;
                    Remain.Text = z.ToString();
                    float n = x + a;
                    Paid.Text = n.ToString();
                }
                else
                {
                    MessageBox.Show("must enter now value smaller than old value"); textBox1
              .Text = "";
                }
            }
            catch { }
        }
        
        
    }
}
