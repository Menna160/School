﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HrSchools
{
    public partial class ResultControl : Form
    {
        public ResultControl()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Control_Room c = new Control_Room();
            c.Show();
            this.Hide();

        }

        private void button7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            InsertResult r = new InsertResult();
            r.Show();
            this.Hide();
        }

        private void ResultControl_Load(object sender, EventArgs e)
        {
          
        }

        private void button2_Click(object sender, EventArgs e)
        {
            otherOperation t = new otherOperation();
            t.Save.Enabled = false;
            t.groupBox1.Enabled = false;
            t.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            otherOperation t = new otherOperation();
            t.button1.Enabled = false;
            t.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Search_StudentResult s = new Search_StudentResult();
            s.Show();
           this.Hide();
        }
    }
}
