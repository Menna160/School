﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HrSchools
{
    public partial class insertfees : Form
    {
        public insertfees()
        {
            InitializeComponent();
        }

        private void insertfees_Load(object sender, EventArgs e)
        {
            groupBox2.Enabled = false;
            txtPrice.Text = textBox1.Text;
            
            comboBox1.Text = "Select the method to paid";
            comboBox2.Text = "Select discount";
            cost.Enabled = false;
            ConnectionClass c = new ConnectionClass();
            c.PoolConnection();
            c.CMD.CommandText = "select max(costid) from Costs";
            c.DR = c.CMD.ExecuteReader();
            while (c.DR.Read())
            {
                int a = Convert.ToInt32(c.DR[0].ToString()+0);

                cost.Text = (a + 1).ToString();



            }


        }

        private void Save_Click(object sender, EventArgs e)
        {

            if (TXTName.Text == "" || txtPrice.Text == "")
            {
                MessageBox.Show("Please Enter Data", "Message", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            }
            else
            {
                float tot = Convert.ToInt32(textBox1.Text);
                int a = Convert.ToInt32(cost.Text);
                float b = Convert.ToInt32(txtPrice.Text);
                float d = Convert.ToInt32(comboBox2.SelectedItem);
                         
                //string x;
                //x = DateTime.Now.ToString();

                float t = Convert.ToInt32(costPaid.Text);
                float r = Convert.ToInt32(Remain.Text);
                ConnectionClass c = new ConnectionClass();
                c.PoolConnection();
                c.CMD.CommandText = "insert into costs values(" + a + ",'" + comboBox1.SelectedItem + "'," + b + "," + d + "," + t + ",'" + dateTimePicker1.Value + "'," + r + ",'" + TXTName.Text + "'," + tot + ")";
                c.CMD.ExecuteNonQuery();
                DialogResult ww = MessageBox.Show("Data Saved Suucessfully", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                if (ww == DialogResult.OK)
                {
                    groupBox2.Enabled = false;
                    txtPrice.Text = textBox1.Text;
                     comboBox1.Text = "Select the method to paid";
                    comboBox2.Text = "Select discount";
                    cost.Enabled = false;
                    ConnectionClass c1 = new ConnectionClass();
                    c1.PoolConnection();
                    c1.CMD.CommandText = "select max(costid) from Costs";
                    c1.DR = c1.CMD.ExecuteReader();
                    while (c1.DR.Read())
                    {
                        int inc = Convert.ToInt32(c1.DR[0].ToString());

                        cost.Text = (inc + 1).ToString();



                    }
                    txtPrice.Text = "";
                    TXTName.Text = "";
                    Remain.Text = "";
                    textBox1.Text = "";
                    comboBox1.Text = "Select Payement";
                    comboBox2.Text = "Selcet Discount ";
                    costPaid.Text="";
                    dateTimePicker1.Value.ToShortTimeString();
                }
            }


        }

        private void txtPrice_TextChanged(object sender, EventArgs e)
        {
            try
            {
                float b = Convert.ToInt32(txtPrice.Text);

                float d = Convert.ToInt32(comboBox2.SelectedItem);
                float t = (b * d) / 100;
                float price = d - t;
                textBox1.Text = price.ToString();
            }
            catch { }
        }



        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox1.Enabled = true;
            try
            {
                float b = Convert.ToInt32(txtPrice.Text);
                float d = Convert.ToInt32(comboBox2.SelectedItem);
                float r = (b * d) / 100;
                float t = b - r;
                textBox1.Text = t.ToString();
            }
            catch { }
        }

        private void costPaid_TextChanged(object sender, EventArgs e)
        {
            try
            {
                float tot = Convert.ToInt32(textBox1.Text);
                float t = Convert.ToInt32(costPaid.Text);
                if (tot > t)
                {
                    float s = tot - t;
                    Remain.Text = s.ToString();
                }
                else
                {
                    int a = 0;
                    Remain.Text = a.ToString();
                }
            }
            catch { }
        }

        private void TXTName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar < 50 || e.KeyChar > 500)
            {
                e.Handled = true;
            }
        }

        private void txtPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            { e.Handled = true; }
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            { e.Handled = true; }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            { e.Handled = true; }
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            { e.Handled = true; }
        }

        private void costPaid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            { e.Handled = true; }
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            { e.Handled = true; }
        }


        private void Remain_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            { e.Handled = true; }
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            { e.Handled = true; }
        }

        private void cost_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            { e.Handled = true; }
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            { e.Handled = true; }
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            txtPrice.Text = "";
            TXTName.Text = "";
            Remain.Text = "";
            //cost.Text = "";

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Cash")
            {
                int t = Convert.ToInt32(textBox1.Text);
                costPaid.Text = t.ToString();

            }
            else if (comboBox1.Text == "No")
            {
                int a = 0;
                txtPrice.Text = a.ToString();
                textBox1.Text = a.ToString();
                costPaid.Text = a.ToString();

            }
            //else if (comboBox1.Text == "More Times")
            //{

            //    float b = Convert.ToInt32(txtPrice.Text);

            //    float d = Convert.ToInt32(comboBox2.SelectedItem);
            //    float t = (b * d) / 100;
            //    float price = d - t;
            //    textBox1.Text = price.ToString();
            //}
            else { }
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            FeesControl f = new FeesControl();
            f.Show();
            this.Hide();
        }

        private void BTNclose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void TXTName_TextChanged(object sender, EventArgs e)
        {
            AutoCompleteStringCollection ayman = new AutoCompleteStringCollection();


            ConnectionClass con = new ConnectionClass();
            con.PoolConnection();
            con.CMD.CommandText = "select stdname from Student where stdname  like +@name+'%'";
            con.CMD.Parameters.Add("@name", SqlDbType.NVarChar, 50).Value = TXTName.Text;
            con.DR = con.CMD.ExecuteReader();
            while (con.DR.Read())
            {

                ayman.Add(con.DR[0].ToString());

            }
            TXTName.AutoCompleteMode = AutoCompleteMode.Suggest;
            TXTName.AutoCompleteSource = AutoCompleteSource.CustomSource;
            TXTName.AutoCompleteCustomSource = ayman;
            //check for valited
            ConnectionClass con1 = new ConnectionClass();
            con1.PoolConnection();
            con1.CMD.CommandText = "Select Studentname from result where studentname='" + TXTName.Text + "'";
            con1.DR = con1.CMD.ExecuteReader();
            if (con1.DR.Read())
            {
                DialogResult r = MessageBox.Show("You Enter Fess Befor would you like to update this date ", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (r == DialogResult.Yes)
                {
                    FeesOpreation f = new FeesOpreation();
                    f.Show();
                    this.Hide();

                }
                else { groupBox2.Enabled = true; }
            }

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void TXTName_TextChanged_1(object sender, EventArgs e)
        {
            AutoCompleteStringCollection ayman = new AutoCompleteStringCollection();
            ConnectionClass con = new ConnectionClass();
            con.PoolConnection();
            con.CMD.CommandText = "select stdname from Student where stdname  like +@name+'%'";
            con.CMD.Parameters.Add("@name", SqlDbType.NVarChar, 50).Value = TXTName.Text;
            con.DR = con.CMD.ExecuteReader();
            while (con.DR.Read())
            {

                ayman.Add(con.DR[0].ToString());

            }
            TXTName.AutoCompleteMode = AutoCompleteMode.Suggest;
            TXTName.AutoCompleteSource = AutoCompleteSource.CustomSource;
            TXTName.AutoCompleteCustomSource = ayman;
            //check for valited







        }

        private void button1_Click(object sender, EventArgs e)
        {
            ConnectionClass c = new ConnectionClass();
            c.PoolConnection();
            c.CMD.CommandText = "Select Studentname from Costs where studentname='"+TXTName.Text+"'";
            c.DR = c.CMD.ExecuteReader();
            if (c.DR.Read())
            {
                DialogResult r = MessageBox.Show("You Enter Fess Before would you like to update OR Delete this data ", "Message", MessageBoxButtons.OK, MessageBoxIcon.Question);
                if (r == DialogResult.OK)
                {
                    FeesOpreation f = new FeesOpreation();
                    f.Show();
                    this.Hide();

                }
          
            }

            else
            {
                MessageBox.Show("Now,you enter Fees for this Student", "Message", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                groupBox2.Enabled = true;
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void TXTName_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && e.KeyChar != ' ')
            {
                e.Handled = true;
            }


            if (e.KeyChar == ' '
                && (sender as TextBox).Text.IndexOf(' ') > -1)
            {
                e.Handled = true;
            }
            
            
        }
        }

    }



       
   

