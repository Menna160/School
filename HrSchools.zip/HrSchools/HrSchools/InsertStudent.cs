﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace HrSchools
{
    public partial class insertstudent : Form
    {
        public insertstudent()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void InsertStudent_Load(object sender, EventArgs e)
        {
            TXTSTDNO.Enabled = false;
            ConnectionClass con = new ConnectionClass();
            con.PoolConnection();
            con.CMD.CommandText = "select Max(stdid) from Student";
            con.DR = con.CMD.ExecuteReader();
            if (con.DR.Read())
            {
                int a = Convert.ToInt32(con.DR[0].ToString()+0);

                TXTSTDNO.Text = (a + 1).ToString();

            }
            else {
                int b=0;
                TXTSTDNO.Text = b.ToString();
            }

            comboBox1.Text = "Select Number of class";
            comboGender.Text = "Select yor Gender";
            ComboStd.Text = "Select Your Stage ";
           
        }

        private void BTNclose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            StudentControl s = new StudentControl();
            s.Show();
            this.Hide();
        }

        

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Save_Click(object sender, EventArgs e)
        {
            

            // int a = Convert.ToInt32(TXTClassno.Text);
            if (txtnae.Text == "" || TXTAddress.Text == "")
            {
                MessageBox.Show("Ensert Data Please", "erroe Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                
                int b = Convert.ToInt32(TXTSTDNO.Text);
                ConnectionClass con = new ConnectionClass();
                con.PoolConnection();
                con.CMD.CommandText = "Insert into class values('" + comboBox1.SelectedItem + "','" + ComboStd.SelectedItem + "')";
                con.CMD.ExecuteNonQuery();
                con.CMD.CommandText = "Insert into Student(stdid,stdname,stdBirthdate,stdaddress,stdGender,stdArrive,Classname) values(" + b + ",'" + txtnae.Text + "','"+StdTime.Text+"','" + TXTAddress.Text + "','" + comboGender.SelectedItem + "','" + dateTimePicker1.Text + "','" + ComboStd.SelectedItem +"')";

    
                DialogResult r = MessageBox.Show("You AreWant  Save This Data in your Program", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (r == DialogResult.Yes)
                {

                    con.CMD.ExecuteNonQuery();
                    DialogResult r1 = MessageBox.Show("Data Save Succesfully", "Message", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    if (r1 == DialogResult.OK)
                    {
                       // ConClass con = new ConClass();
                        con.PoolConnection();
                        con.CMD.CommandText = "select Max(stdid) from Student";
                        con.DR = con.CMD.ExecuteReader();
                        while (con.DR.Read())
                        {
                            int a = Convert.ToInt32(con.DR[0].ToString());

                            TXTSTDNO.Text =( a+1) .ToString();
                            a++;

                        }
                        TXTAddress.Text = "";
                        // TXTClassno.Text = "";
                        txtnae.Text = "";

                        comboGender.Text = "select Gender";
                        ComboStd.Text = "select Stage";
                        comboBox1.Text = "Select Number of class";
                    }
                }
                else
                {

                   // TXTAddress.Text = "";
                    //  TXTClassno.Text = "";
                    TXTName.Text = "";
                    TXTSTDNO.Text = "";
                    comboGender.Text = "select Gender";
                    ComboStd.Text = "select Stage";
                    comboBox1.Text = "Select Number of class";



                }
            }



        }
        private void TXTSTDNO_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void ComboStd_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            if (ComboStd.Text == "First")
            {
                comboBox1.Items.Add("1/1");
                comboBox1.Items.Add("1/2");
                comboBox1.Items.Add("1/2");


            }
            else  if (ComboStd.Text == "Second")
            {
                comboBox1.Items.Add("2/1");
                comboBox1.Items.Add("2/2");
                comboBox1.Items.Add("2/3");


            }
            else if (ComboStd.Text == "third")
            {
                comboBox1.Items.Add("3/1");
                comboBox1.Items.Add("3/2");
                comboBox1.Items.Add("3/3");


            }
            else
            {
                comboBox1.Text = "Select Number of class";
            
            }
        }

        private void TXTAddress_KeyPress(object sender, KeyPressEventArgs e)
        {
           
        }

        private void txtnae_TextChanged(object sender, EventArgs e)
        {
            
        }

        

        private void txtnae_KeyPress(object sender, KeyPressEventArgs e)
        {
        
            
            if (!char.IsControl(e.KeyChar)&& !char.IsLetter(e.KeyChar)&& e.KeyChar != ' ')
            {
                e.Handled = true;
            }

            
            if (e.KeyChar == ' '
                && (sender as TextBox).Text.IndexOf(' ') > -1)
            {
                e.Handled = true;
            }
            
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void TXTSTDNO_TextChanged(object sender, EventArgs e)
        {

        }

       
    }
}

