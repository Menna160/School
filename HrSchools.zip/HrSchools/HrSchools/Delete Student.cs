﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HrSchools
{
    public partial class Delete_Student : Form
    {
        public Delete_Student()
        {
            InitializeComponent();
        }

        private void searchUpdate_Click(object sender, EventArgs e)
        {
            ConnectionClass cn=new ConnectionClass ();
                    cn.PoolConnection();
                    cn.CMD.CommandText = "Select stdid,stdname,classname from Student where stdname= '"+TXTnamesDelete.Text+"'";
                    cn.DR = cn.CMD.ExecuteReader();
                    if (cn.DR.Read())
                    {
                        TXTName.Text = cn.DR[1].ToString();
                        Txtno.Text = cn.DR[0].ToString();
                        ComboStd.Text = cn.DR[2].ToString();

                    }
                    else 
                    {
                        DialogResult r=MessageBox.Show("No Student For this name please Check name Again","Message",MessageBoxButtons.OK,MessageBoxIcon.Error);
                        if (r == DialogResult.OK)
                        {
                            TXTnamesDelete.Text = "";
                        }
                    }

        }

        private void Delete_Student_Load(object sender, EventArgs e)
        {
            //TXTClassno.Enabled = false;
            TXTName.Enabled = false;
            Txtno.Enabled = false;
            ComboStd.Enabled = false;
            
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            StudentControl s = new StudentControl();
            s.Show();
            this.Hide();
        }

        private void BTNclose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void TXTName_TextChanged(object sender, EventArgs e)
        {

        }

        private void BTNdelete_Click(object sender, EventArgs e)
        {
            if (TXTnamesDelete.Text == "")
            { MessageBox.Show("You must enter Student name to Delete"); }
            else
            {
                DialogResult r1 = MessageBox.Show("Notice that you are Delete This Student", "Meessage", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                if (r1 == DialogResult.Yes)
                {
                    ConnectionClass cn = new ConnectionClass();
                    cn.PoolConnection();
                    cn.CMD.CommandText = "delete Student where Stdname='" + TXTnamesDelete.Text + "'";
                    cn.CMD.ExecuteNonQuery();
                    DialogResult r = MessageBox.Show("Student Deleted", "Message", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    if (r == DialogResult.OK)
                    {
                        TXTnamesDelete.Text = "";
                        TXTName.Text = "";
                        Txtno.Text = "";
                        ComboStd.Text = "";
                    }
                }
                else
                {
                    StudentControl s = new StudentControl();
                    s.Show();
                    this.Hide();
                }
            }
        }
        private void BtnClear_Click(object sender, EventArgs e)
        {

            TXTnamesDelete.Text = "";
            TXTName.Text = "";
            Txtno.Text = "";
            ComboStd.Text = "";

        }

        private void TXTnamesDelete_TextChanged(object sender, EventArgs e)
        {
            AutoCompleteStringCollection ayman = new AutoCompleteStringCollection();


            ConnectionClass con = new ConnectionClass();
            con.PoolConnection();
            con.CMD.CommandText = "select stdname from Student where stdname  like +@name+'%'";
            con.CMD.Parameters.Add("@name", SqlDbType.NVarChar, 50).Value = TXTnamesDelete.Text;
            con.DR = con.CMD.ExecuteReader();
            while (con.DR.Read())
            {
                // listBox1.Items.Add(con.DR[0].ToString());
                ayman.Add(con.DR[0].ToString());

            }
            TXTnamesDelete.AutoCompleteMode = AutoCompleteMode.Suggest;
            TXTnamesDelete.AutoCompleteSource = AutoCompleteSource.CustomSource;
            TXTnamesDelete.AutoCompleteCustomSource = ayman;
        }

        private void TXTnamesDelete_KeyPress(object sender, KeyPressEventArgs e)
        {
            //if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && e.KeyChar != ' ')
            //{
            //    e.Handled = true;
            //}


            //if (e.KeyChar == ' '
            //    && (sender as TextBox).Text.IndexOf(' ') > -1)
            //{
            //    e.Handled = true;
            //}
            
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
